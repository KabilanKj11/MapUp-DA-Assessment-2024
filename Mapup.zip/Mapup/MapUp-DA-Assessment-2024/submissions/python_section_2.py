import pandas as pd 


def calculate_distance_matrix(df)->pd.DataFrame():
    """
    Calculate a distance matrix based on the dataframe, df.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame: Distance matrix
    """
    # Write your logic here
    unique_ids = df['id_start'].unique()
    distance_matrix = pd.DataFrame(0, index=unique_ids, columns=unique_ids)
    
    for _, row in df.iterrows():
        id_start = row['id_start']
        id_end = row['id_end']
        distance = row['distance']
        
        
        distance_matrix.loc[id_start, id_end] = distance
        distance_matrix.loc[id_end, id_start] = distance

    return distance_matrix


def unroll_distance_matrix(df)->pd.DataFrame():
    """
    Unroll a distance matrix to a DataFrame in the style of the initial dataset.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame: Unrolled DataFrame containing columns 'id_start', 'id_end', and 'distance'.
    """
    # Write your logic here
    unrolled_data = []

    for id_start in df.index:
        for id_end in df.columns:
            if id_start != id_end:
                distance = df.loc[id_start, id_end]
                unrolled_data.append([id_start, id_end, distance])
    
    return pd.DataFrame(unrolled_data, columns=['id_start', 'id_end', 'distance'])


def find_ids_within_ten_percentage_threshold(df, reference_id)->pd.DataFrame():
    """
    Find all IDs whose average distance lies within 10% of the average distance of the reference ID.

    Args:
        df (pandas.DataFrame)
        reference_id (int)

    Returns:
        pandas.DataFrame: DataFrame with IDs whose average distance is within the specified percentage threshold
                          of the reference ID's average distance.
    """
    
    ref_distances = df[df['id_start'] == reference_id]['distance']
    avg_distance = ref_distances.mean()

    
    lower_bound = avg_distance * 0.9
    upper_bound = avg_distance * 1.1

    
    filtered_df = df[(df['distance'] >= lower_bound) & (df['distance'] <= upper_bound)]
    
    return filtered_df[['id_start', 'id_end']]


def calculate_toll_rate(df)->pd.DataFrame():
    """
    Calculate toll rates for each vehicle type based on the unrolled DataFrame.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame
    """
    # Wrie your logic here
    rates = {
        'moto': 0.8,
        'car': 1.2,
        'rv': 1.5,
        'bus': 2.2,
        'truck': 3.6
    }

    
    for vehicle, rate in rates.items():
        df[vehicle] = df['distance'] * rate
    
    return df


def calculate_time_based_toll_rates(df)->pd.DataFrame():
    """
    Calculate time-based toll rates for different time intervals within a day.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame
    """
    # Write your logic here
    time_intervals = [
        {'start_time': datetime.time(0, 0), 'end_time': datetime.time(10, 0), 'factor': 0.8},
        {'start_time': datetime.time(10, 0), 'end_time': datetime.time(18, 0), 'factor': 1.2},
        {'start_time': datetime.time(18, 0), 'end_time': datetime.time(23, 59), 'factor': 0.8}
    ]
    
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    weekend_days = ['Saturday', 'Sunday']

    rows = []
    for _, row in df.iterrows():
        for day in days:
            for interval in time_intervals:
                modified_row = row.copy()
                modified_row['start_day'] = day
                modified_row['start_time'] = interval['start_time']
                modified_row['end_time'] = interval['end_time']
                for vehicle in ['moto', 'car', 'rv', 'bus', 'truck']:
                    modified_row[vehicle] *= interval['factor']
                rows.append(modified_row)
        
        # Apply weekend discount
        for day in weekend_days:
            modified_row = row.copy()
            modified_row['start_day'] = day
            modified_row['start_time'] = datetime.time(0, 0)
            modified_row['end_time'] = datetime.time(23, 59)
            for vehicle in ['moto', 'car', 'rv', 'bus', 'truck']:
                modified_row[vehicle] *= 0.7
            rows.append(modified_row)
    
    return pd.DataFrame(rows)